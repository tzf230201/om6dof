"""Generate reproducible method figures for the ICRA reachability paper."""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch, Rectangle


OUT = Path(__file__).resolve().parent

BLUE = "#2F77B4"
GREEN = "#2A8B62"
ORANGE = "#B87900"
MAGENTA = "#A13B72"
RED = "#C74440"
INK = "#17324D"
GRAY = "#A5B2BF"
LIGHT = "#EDF3F7"


def halton(n: int, bases: tuple[int, int] = (2, 3), offset: int = 1) -> np.ndarray:
    def radical_inverse(index: int, base: int) -> float:
        value = 0.0
        factor = 1.0 / base
        while index:
            value += factor * (index % base)
            index //= base
            factor /= base
        return value

    return np.array(
        [[radical_inverse(i, bases[0]), radical_inverse(i, bases[1])]
         for i in range(offset, offset + n)],
        dtype=float,
    )


def valid_region(points: np.ndarray) -> np.ndarray:
    x, y = points[:, 0], points[:, 1]
    outer = ((x - 0.50) / 0.47) ** 2 + ((y - 0.50) / 0.43) ** 2 <= 1.0
    notch = (x > 0.43) & (x < 0.58) & (y < 0.42)
    return outer & ~notch


def candidate_pool(n: int = 2200) -> np.ndarray:
    raw = halton(n * 2, offset=19)
    return raw[valid_region(raw)][:n]


def kmeans(points: np.ndarray, k: int, iterations: int = 24) -> np.ndarray:
    centers = points[np.linspace(0, len(points) - 1, k, dtype=int)].copy()
    for _ in range(iterations):
        d2 = ((points[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2)
        labels = d2.argmin(axis=1)
        for idx in range(k):
            members = points[labels == idx]
            if len(members):
                centers[idx] = members.mean(axis=0)
    return centers


def draw_configuration_panel(ax, title: str, subtitle: str, nodes: np.ndarray,
                             node_color: str, guards: np.ndarray | None = None) -> None:
    pool = candidate_pool()
    ax.scatter(pool[:, 0], pool[:, 1], s=2.0, color="#D7E0E7", alpha=0.55,
               linewidths=0, rasterized=True)
    ax.add_patch(Rectangle((0.43, 0.0), 0.15, 0.42, facecolor=RED,
                           edgecolor="none", alpha=0.14))
    ax.text(0.505, 0.18, "invalid\nregion", ha="center", va="center",
            fontsize=7, color=RED, weight="bold")
    ax.add_patch(Circle((0.82, 0.72), 0.095, facecolor=MAGENTA,
                        edgecolor=MAGENTA, alpha=0.10, linewidth=1.2))
    ax.text(0.82, 0.84, "target\nneighborhood", ha="center", va="bottom",
            fontsize=7, color=MAGENTA)
    ax.scatter(nodes[:, 0], nodes[:, 1], s=18, color=node_color,
               edgecolor="white", linewidth=0.35, zorder=4,
               label="prototype / roadmap node")
    if guards is not None:
        ax.scatter(guards[:, 0], guards[:, 1], s=16, marker="s", color=ORANGE,
                   edgecolor="white", linewidth=0.3, zorder=5,
                   label="deterministic guard")
    ax.scatter([0.18], [0.24], s=58, marker="*", color=GREEN,
               edgecolor="white", linewidth=0.5, zorder=7)
    ax.scatter([0.82], [0.72], s=58, marker="*", color=MAGENTA,
               edgecolor="white", linewidth=0.5, zorder=7)
    ax.set_title(title, fontsize=10.2, color=INK, weight="bold", pad=5)
    ax.text(0.5, -0.10, subtitle, transform=ax.transAxes, ha="center",
            va="top", fontsize=7.6, color="#3E5263")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xlabel("normalized joint projection $q_a$", fontsize=7.5, labelpad=2)
    ax.set_ylabel("$q_b$", fontsize=7.5, labelpad=1)
    for spine in ax.spines.values():
        spine.set_color("#B8C5CF")
        spine.set_linewidth(0.7)


def roadmap_construction() -> None:
    pool = candidate_pool()

    # GNG illustration: quantization follows the dense candidate distribution.
    dense_weights = 1.0 + 3.5 * np.exp(-(((pool[:, 0] - 0.36) / 0.22) ** 2
                                          + ((pool[:, 1] - 0.52) / 0.28) ** 2))
    repeat = np.clip(np.rint(dense_weights).astype(int), 1, 5)
    weighted = np.repeat(pool, repeat, axis=0)
    gng_nodes = kmeans(weighted, 72)

    # Hybrid illustration: fewer prototypes plus globally supportive guards.
    hybrid_prototypes = kmeans(weighted, 22)
    guard_candidates = halton(420, offset=713)
    hybrid_guards = guard_candidates[valid_region(guard_candidates)][:54]

    # Direct low-discrepancy roadmap nodes.
    direct = halton(700, offset=121)
    direct = direct[valid_region(direct)][:76]

    fig, axes = plt.subplots(1, 3, figsize=(12.4, 3.65), constrained_layout=False)
    fig.patch.set_facecolor("white")
    draw_configuration_panel(
        axes[0], "GNG-quantized PRM",
        "2 anchors + 798 prototypes; learned GNG adjacency is discarded",
        gng_nodes, BLUE,
    )
    draw_configuration_panel(
        axes[1], "Guarded GNG",
        "2 anchors + 199 prototypes + 599 low-discrepancy guards",
        hybrid_prototypes, BLUE, hybrid_guards,
    )
    draw_configuration_panel(
        axes[2], "Halton/PRM",
        "2 anchors + 798 direct digit-permuted Halton nodes",
        direct, GRAY,
    )
    fig.subplots_adjust(left=0.045, right=0.985, top=0.79, bottom=0.23, wspace=0.20)
    fig.suptitle("Method-specific node construction under the same 800-node budget",
                 x=0.5, y=0.985, fontsize=13.2, color=INK, weight="bold")
    fig.text(0.5, 0.875,
             "Schematic 2-D projection; marker count is illustrative, while labels report the deployed composition.",
             ha="center", va="center", fontsize=8.4, color="#536979")
    fig.text(0.5, 0.045,
             "All three node sets use the same validated $k$-nearest-neighbor connection rule, edge limits, and collision predicates.",
             ha="center", va="center", fontsize=8.6, color=INK, weight="bold")
    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"roadmap_construction.{ext}", dpi=320,
                    bbox_inches="tight", facecolor="white")
    plt.close(fig)


def rounded_box(ax, xy, wh, title, body, edge, face, title_color=INK, body_size=7.2):
    x, y = xy
    w, h = wh
    patch = FancyBboxPatch(
        (x, y), w, h,
        boxstyle="round,pad=0.012,rounding_size=0.018",
        linewidth=1.25, edgecolor=edge, facecolor=face,
    )
    ax.add_patch(patch)
    ax.text(x + 0.018, y + h - 0.045, title, ha="left", va="top",
            fontsize=8.8, color=title_color, weight="bold")
    ax.text(x + 0.018, y + h - 0.105, body, ha="left", va="top",
            fontsize=body_size, color="#253B4D", linespacing=1.27)
    return patch


def arrow(ax, start, end, color=INK, rad=0.0, label=None, label_xy=None):
    p = FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=11,
                        linewidth=1.25, color=color,
                        connectionstyle=f"arc3,rad={rad}")
    ax.add_patch(p)
    if label:
        lx, ly = label_xy if label_xy is not None else (
            (start[0] + end[0]) / 2, (start[1] + end[1]) / 2)
        ax.text(lx, ly, label, fontsize=7.1, color=color, ha="center",
                va="center", weight="bold",
                bbox=dict(boxstyle="round,pad=0.15", facecolor="white",
                          edgecolor="none", alpha=0.92))


def query_pipeline() -> None:
    fig, ax = plt.subplots(figsize=(12.4, 4.0))
    fig.patch.set_facecolor("white")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    ax.text(0.02, 0.965, "Environment-conditioned graph query and lazy exact validation",
            fontsize=13.0, color=INK, weight="bold", va="top")
    ax.text(0.02, 0.905,
            "A query preserves the 6-DoF configuration branch; failed exact edges are disabled only for the current environment revision.",
            fontsize=8.3, color="#536979", va="top")

    rounded_box(ax, (0.025, 0.55), (0.145, 0.24), "1  Atomic query",
                "$q_s$ measured start\nsemantic target $t$\nobstacle points/segments\nscene + graph revision",
                BLUE, "#EAF3FA")
    rounded_box(ax, (0.215, 0.55), (0.145, 0.24), "2  Candidate goals",
                r"EE distance $\leq r_I$" "\ncollision-free node\nsame start component\nretain every IK branch",
                MAGENTA, "#F8EDF3")
    rounded_box(ax, (0.405, 0.55), (0.145, 0.24), "3  Broad phase",
                "cached body capsules\npoint/segment distance\nblock nodes and edges\nno roadmap rebuild",
                ORANGE, "#FCF4E5")
    rounded_box(ax, (0.595, 0.55), (0.145, 0.24), "4  Graph search",
                "Dijkstra over enabled edges\njoint-space accumulated cost\nselect reachable target node\nreconstruct route",
                GREEN, "#EAF5EF")
    rounded_box(ax, (0.785, 0.55), (0.185, 0.24), "5  Exact validation",
                "interpolate every route edge\nMoveIt RobotState + FCL\nself + environment collision\nmaximum 20 replans",
                MAGENTA, "#F8EDF3")

    for x0, x1 in ((0.17, 0.215), (0.36, 0.405), (0.55, 0.595), (0.74, 0.785)):
        arrow(ax, (x0, 0.67), (x1, 0.67), color=INK)

    rounded_box(ax, (0.61, 0.17), (0.20, 0.20), "6a  Edge rejected",
                "blacklist failed edge\nfor this environment revision\nthen rerun Dijkstra",
                RED, "#FBEDEC")
    rounded_box(ax, (0.84, 0.17), (0.13, 0.20), "6b  Accepted",
                "exact-valid path\nprivate preview topic\nno controller endpoint",
                GREEN, "#EAF5EF", body_size=6.9)

    arrow(ax, (0.865, 0.55), (0.765, 0.37), color=RED,
          label="collision", label_xy=(0.825, 0.44))
    arrow(ax, (0.665, 0.37), (0.67, 0.55), color=RED,
          label="replan", label_xy=(0.635, 0.46))
    arrow(ax, (0.915, 0.55), (0.91, 0.37), color=GREEN,
          label="all states valid", label_xy=(0.925, 0.46))

    ax.text(0.025, 0.30, "Validity hierarchy", fontsize=8.5, color=INK, weight="bold")
    ax.text(0.025, 0.235,
            r"capsules (fast, conservative)  $\rightarrow$  graph route  $\rightarrow$  interpolated mesh collision (authoritative)",
            fontsize=8.0, color="#334B5D")
    ax.text(0.025, 0.145,
            "Safety boundary: benchmark output is a trajectory preview only; it does not publish to /arm_controller and has no action client.",
            fontsize=7.8, color=RED, weight="bold",
            bbox=dict(boxstyle="round,pad=0.28", facecolor="#FBEDEC",
                      edgecolor=RED, linewidth=0.9))

    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"lazy_query_pipeline.{ext}", dpi=320,
                    bbox_inches="tight", facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    roadmap_construction()
    query_pipeline()
    print("Generated roadmap_construction and lazy_query_pipeline (PDF + PNG).")
