#!/usr/bin/env python3
"""Repeatable preview-only GNG, guarded-GNG, and Halton/PRM benchmark.

The controller launches one isolated reachability process per method/seed. A
probe child publishes synthetic JointState and typed EnvironmentGraph messages,
then records both a clear path and a replanning case with an obstacle on the
original route. Nothing in this script publishes to a controller topic.
"""

import argparse
import csv
import itertools
import json
import math
import os
import signal
import subprocess
import sys
import time
from pathlib import Path


def summarize_plan(message):
    return {
        "valid": bool(message.valid),
        "reason": message.reason,
        "blocked_nodes": int(message.blocked_node_count),
        "blocked_edges": int(message.blocked_edge_count),
        "planning_time_ms": float(message.planning_time_ms),
        "exact_valid": bool(message.exact_collision_valid),
        "exact_checks": int(message.exact_state_checks),
        "exact_replans": int(message.exact_replans),
        "exact_time_ms": float(message.exact_validation_time_ms),
        "path_nodes": len(message.reachability_node_ids),
        "path_ids": list(message.reachability_node_ids),
    }


def run_probe(timeout):
    import rclpy
    from geometry_msgs.msg import Point
    from rclpy.node import Node
    from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
    from sensor_msgs.msg import JointState
    from om6dof_dd_gng.msg import (
        EnvironmentGraph,
        EnvironmentNode,
        ReachabilityGraph,
        ReachabilityPlan,
    )

    class Probe(Node):
        def __init__(self):
            super().__init__("reachability_benchmark_probe")
            latched = QoSProfile(depth=1)
            latched.reliability = ReliabilityPolicy.RELIABLE
            latched.durability = DurabilityPolicy.TRANSIENT_LOCAL
            self.create_subscription(
                ReachabilityGraph,
                "/om6dof_topo_gng/reachability_graph_data",
                self.graph_callback,
                latched,
            )
            self.create_subscription(
                ReachabilityPlan,
                "/om6dof_topo_gng/reachability_plan",
                self.plan_callback,
                latched,
            )
            self.joint_pub = self.create_publisher(JointState, "/joint_states", 10)
            self.environment_pub = self.create_publisher(
                EnvironmentGraph, "/om6dof_topo_gng/environment_graph_data", 10
            )
            self.graph = None
            self.start = None
            self.goal = None
            self.obstacle_position = None
            self.clear = None
            self.dynamic = None
            self.phase = "waiting_graph"
            self.last_publish = 0.0

        def graph_callback(self, message):
            if self.graph is not None or not message.nodes:
                return
            self.graph = message
            self.start = message.nodes[0]
            # Node 0 is the default all-zero state. The graph builder inserts
            # the SRDF home_pose immediately afterwards, before any method-
            # dependent samples, so node 1 is the same executable target for
            # GNG and Halton/PRM. This keeps paired planning queries matched.
            if len(message.nodes) < 2:
                return
            self.goal = message.nodes[1]
            self.obstacle_position = Point()
            self.obstacle_position.x = 0.5 * (
                self.start.pose.position.x + self.goal.pose.position.x
            )
            self.obstacle_position.y = 0.5 * (
                self.start.pose.position.y + self.goal.pose.position.y
            )
            self.obstacle_position.z = 0.5 * (
                self.start.pose.position.z + self.goal.pose.position.z
            )
            self.phase = "clear"

        def publish_inputs(self):
            joint_state = JointState()
            joint_state.header.stamp = self.get_clock().now().to_msg()
            joint_state.name = list(self.graph.joint_names)
            joint_state.position = list(self.start.joint_positions)
            self.joint_pub.publish(joint_state)

            environment = EnvironmentGraph()
            environment.header.stamp = joint_state.header.stamp
            environment.header.frame_id = "world"
            target = EnvironmentNode()
            target.id = 900001
            target.position = self.goal.pose.position
            target.class_id = 1
            target.confidence = 1.0
            environment.nodes.append(target)
            if self.phase == "dynamic" and self.obstacle_position is not None:
                obstacle = EnvironmentNode()
                obstacle.id = 900002
                obstacle.position = self.obstacle_position
                obstacle.class_id = -1
                obstacle.confidence = 1.0
                environment.nodes.append(obstacle)
            self.environment_pub.publish(environment)

        def plan_callback(self, message):
            if self.graph is None:
                return
            if self.phase == "clear" and message.valid and message.exact_collision_valid:
                self.clear = summarize_plan(message)
                self.phase = "dynamic"
            elif self.phase == "dynamic" and message.blocked_edge_count > 0:
                self.dynamic = summarize_plan(message)
                self.phase = "done"

    rclpy.init()
    probe = Probe()
    deadline = time.monotonic() + timeout
    try:
        while rclpy.ok() and probe.phase != "done" and time.monotonic() < deadline:
            rclpy.spin_once(probe, timeout_sec=0.05)
            now = time.monotonic()
            if probe.graph is not None and probe.phase in ("clear", "dynamic"):
                if now - probe.last_publish >= 0.2:
                    probe.publish_inputs()
                    probe.last_publish = now
        if probe.phase != "done":
            print(json.dumps({"error": "probe_timeout", "phase": probe.phase}), flush=True)
            return 2
        output = {
            "method": probe.graph.graph_method,
            "nodes": len(probe.graph.nodes),
            "edges": len(probe.graph.edges),
            "components": int(probe.graph.connected_components),
            "build_time_ms": float(probe.graph.build_time_ms),
            "target_xyz": [
                probe.goal.pose.position.x,
                probe.goal.pose.position.y,
                probe.goal.pose.position.z,
            ],
            "target_joints": list(probe.goal.joint_positions),
            "obstacle_xyz": [
                probe.obstacle_position.x,
                probe.obstacle_position.y,
                probe.obstacle_position.z,
            ],
            "clear": probe.clear,
            "dynamic": probe.dynamic,
        }
        print(json.dumps(output, sort_keys=True), flush=True)
        return 0
    finally:
        probe.destroy_node()
        rclpy.shutdown()


def flatten(result, method, seed, run_index, sample_offset, guard_fraction):
    row = {
        "run_index": run_index,
        "method": method,
        "seed": seed,
        "halton_start_index": sample_offset,
        "gng_guard_fraction": guard_fraction if method == "guarded_gng" else 0.0,
        "nodes": result.get("nodes", 0),
        "edges": result.get("edges", 0),
        "components": result.get("components", 0),
        "build_time_ms": result.get("build_time_ms", math.nan),
        "target_xyz": json.dumps(result.get("target_xyz", [])),
        "target_joints": json.dumps(result.get("target_joints", [])),
        "obstacle_xyz": json.dumps(result.get("obstacle_xyz", [])),
    }
    for scenario in ("clear", "dynamic"):
        values = result.get(scenario) or {}
        for key in (
            "valid",
            "reason",
            "blocked_nodes",
            "blocked_edges",
            "planning_time_ms",
            "exact_valid",
            "exact_checks",
            "exact_replans",
            "exact_time_ms",
            "path_nodes",
        ):
            row[f"{scenario}_{key}"] = values.get(key, "")
    row["error"] = result.get("error", "")
    return row


def stop_launch(process):
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGINT)
        process.wait(timeout=8)
    except (ProcessLookupError, subprocess.TimeoutExpired):
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=3)


def run_controller(args):
    script = str(Path(__file__).resolve())
    methods = [item.strip() for item in args.methods.split(",") if item.strip()]
    if len(set(methods)) != len(methods):
        raise SystemExit("--methods must not contain duplicates")
    invalid = set(methods) - {"gng", "guarded_gng", "halton_prm"}
    if invalid:
        raise SystemExit(f"unsupported methods: {sorted(invalid)}")
    schedule = []
    seeds = (
        [int(item.strip()) for item in args.seed_list.split(",") if item.strip()]
        if args.seed_list
        else list(range(args.seeds))
    )
    if not seeds or any(seed < 0 for seed in seeds):
        raise SystemExit("--seed-list must contain non-negative integers")
    method_orders = list(itertools.permutations(methods))
    for seed_index, seed in enumerate(seeds):
        # Cycle through every method permutation. This is equivalent to the
        # previous alternating order for two methods and remains balanced when
        # guarded_gng adds a third method.
        ordered_methods = method_orders[seed_index % len(method_orders)]
        schedule.extend((method, seed) for method in ordered_methods)
    last_domain = args.domain_base + len(schedule) - 1
    if args.domain_base < 0 or last_domain > 232:
        raise SystemExit(
            f"ROS domain range {args.domain_base}..{last_domain} is outside 0..232; "
            "choose a lower --domain-base"
        )

    output = Path(args.output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    with output.open("w", newline="", encoding="utf-8") as stream:
        writer = None
        for run_index, (method, seed) in enumerate(schedule):
            domain = args.domain_base + run_index
            sample_offset = 17 + seed * 7919
            env = os.environ.copy()
            env["ROS_DOMAIN_ID"] = str(domain)
            launch = subprocess.Popen(
                [
                    "ros2",
                    "launch",
                    "om6dof_dd_gng",
                    "reachability_graph.launch.py",
                    "launch_rviz:=false",
                    f"graph_method:={method}",
                    f"sample_count:={args.sample_count}",
                    f"halton_start_index:={sample_offset}",
                    f"gng_guard_fraction:={args.gng_guard_fraction}",
                ],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            try:
                completed = subprocess.run(
                    [sys.executable, script, "--probe", "--timeout", str(args.timeout)],
                    env=env,
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    timeout=args.timeout + 10,
                    check=False,
                )
                lines = [line for line in completed.stdout.splitlines() if line.startswith("{")]
                result = json.loads(lines[-1]) if lines else {
                    "error": f"probe_exit_{completed.returncode}: {completed.stdout[-300:]}"
                }
            except subprocess.TimeoutExpired:
                result = {"error": "probe_process_timeout"}
            finally:
                stop_launch(launch)
            row = flatten(
                result, method, seed, run_index, sample_offset, args.gng_guard_fraction
            )
            rows.append(row)
            if writer is None:
                writer = csv.DictWriter(stream, fieldnames=list(row.keys()))
                writer.writeheader()
            writer.writerow(row)
            stream.flush()
            os.fsync(stream.fileno())
            print(json.dumps(row, sort_keys=True), flush=True)
    print(f"wrote {len(rows)} runs to {output}")
    return 0 if all(not row["error"] for row in rows) else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--probe", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--timeout", type=float, default=35.0)
    parser.add_argument("--methods", default="gng,halton_prm")
    parser.add_argument("--seeds", type=int, default=3)
    parser.add_argument("--seed-list", default="")
    parser.add_argument("--sample-count", type=int, default=800)
    parser.add_argument("--gng-guard-fraction", type=float, default=0.25)
    parser.add_argument("--domain-base", type=int, default=20)
    parser.add_argument("--output", default="reachability_benchmark.csv")
    args = parser.parse_args()
    if args.probe:
        return run_probe(args.timeout)
    if args.seeds < 1 or args.sample_count < 2:
        parser.error("--seeds must be >=1 and --sample-count must be >=2")
    if not 0.0 <= args.gng_guard_fraction <= 0.90:
        parser.error("--gng-guard-fraction must be within [0.0, 0.90]")
    return run_controller(args)


if __name__ == "__main__":
    sys.exit(main())
