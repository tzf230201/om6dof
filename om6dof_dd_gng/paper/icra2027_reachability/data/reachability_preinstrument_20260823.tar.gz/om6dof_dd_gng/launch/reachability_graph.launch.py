"""Launch the preview-only OM6DOF end-effector reachability roadmap.

This launch does not start a camera, move_group, ros2_control, or a hardware
controller. It loads the URDF/SRDF locally for FK and collision checks.
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import Command, FindExecutable, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    share_dir = get_package_share_directory("om6dof_dd_gng")
    moveit_share = get_package_share_directory("om6dof_moveit_config")
    default_params = os.path.join(share_dir, "config", "topo_gng.yaml")
    default_rviz = os.path.join(share_dir, "rviz", "topo_gng.rviz")

    params_file = LaunchConfiguration("params_file")
    launch_rviz = LaunchConfiguration("launch_rviz")
    rviz_config = LaunchConfiguration("rviz_config")
    graph_method = LaunchConfiguration("graph_method")
    sample_count = LaunchConfiguration("sample_count")
    halton_start_index = LaunchConfiguration("halton_start_index")
    gng_guard_fraction = LaunchConfiguration("gng_guard_fraction")

    xacro_file = PathJoinSubstitution([
        FindPackageShare("om6dof_description"), "urdf", "om6dof.urdf.xacro"
    ])
    robot_description = {
        "robot_description": ParameterValue(
            Command([FindExecutable(name="xacro"), " ", xacro_file]),
            value_type=str,
        )
    }
    with open(os.path.join(moveit_share, "config", "om6dof.srdf"), encoding="utf-8") as stream:
        robot_description_semantic = {"robot_description_semantic": stream.read()}

    return LaunchDescription([
        DeclareLaunchArgument(
            "params_file", default_value=default_params,
            description="Shared topo/reachability parameter file",
        ),
        DeclareLaunchArgument(
            "launch_rviz", default_value="true",
            description="Start RViz with the reachability display",
        ),
        DeclareLaunchArgument(
            "rviz_config", default_value=default_rviz,
            description="RViz configuration",
        ),
        DeclareLaunchArgument(
            "graph_method", default_value="gng",
            description="Reachability backend: gng, guarded_gng, or halton_prm",
        ),
        DeclareLaunchArgument(
            "sample_count", default_value="800",
            description="Matched roadmap node budget",
        ),
        DeclareLaunchArgument(
            "halton_start_index", default_value="17",
            description="Deterministic sample-stream offset used as benchmark seed",
        ),
        DeclareLaunchArgument(
            "gng_guard_fraction", default_value="0.25",
            description="Raw deterministic sample fraction reserved by guarded_gng",
        ),
        Node(
            package="om6dof_dd_gng",
            executable="reachability_graph_node",
            name="reachability_graph_node",
            output="screen",
            parameters=[
                params_file,
                robot_description,
                robot_description_semantic,
                {
                    "graph_method": graph_method,
                    "sample_count": ParameterValue(sample_count, value_type=int),
                    "halton_start_index": ParameterValue(
                        halton_start_index, value_type=int
                    ),
                    "gng_guard_fraction": ParameterValue(
                        gng_guard_fraction, value_type=float
                    ),
                },
            ],
        ),
        Node(
            package="rviz2",
            executable="rviz2",
            name="rviz2_reachability",
            output="screen",
            arguments=["-d", rviz_config],
            condition=IfCondition(launch_rviz),
        ),
    ])
